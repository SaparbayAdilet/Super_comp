//
//  main.c
//  Lab1
//
//  Created by Адилет  Сапарбай on 24.10.2023.
//
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

void writeMatricesToFile(int ***matrices, int M, int N) {
    FILE *file = fopen("matrix.txt", "w");
    if (file == NULL) {
        printf("Не удается открыть файл для записи.\n");
        return;
    }

    // Записываем количество матриц и размерность матриц в файл
    fprintf(file, "%d\n%d\n", M, N);

    // Записываем каждую матрицу
    for (int m = 0; m < M; m++) {
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < N; j++) {
                fprintf(file, "%d ", matrices[m][i][j]);
            }
            fprintf(file, "\n");
        }
    }

    fclose(file);
}

void writeAnswerToFile(int **matrix, int M, int N) {
    FILE *file = fopen("answer.txt", "w");
    if (file == NULL) {
        printf("Не удается открыть файл для записи.\n");
        return;
    }

    // Записываем размерность матрицы в файл
    fprintf(file, "%d\n", M);

    // Записываем каждый элемент матрицы
    for (int i = 0; i < M; i++) {
        fprintf(file, "Суммы элементов строк выше главной диагонали для матрицы %d:\n", i+1);
        for (int j = 0; j < N; j++) {
            fprintf(file, "%d ", matrix[i][j]);
        }
        fprintf(file, "\n");
    }

    fclose(file);
}

int main() {
    /*int rows, cols;
    char filename[100];

    printf("Введите количество строк: ");
    scanf("%d", &rows);

    printf("Введите количество столбцов: ");
    scanf("%d", &cols);

    printf("Введите имя файла для записи матрицы: ");
    scanf("%s", filename);

    //srand((unsigned int)time(NULL)); // Инициализируем генератор случайных чисел
    generateAndWriteMatrixToFile(filename, rows, cols);*/
    int N, M;
        // Введите размерность матрицы NxN и количество матриц M
        printf("Введите размерность матрицы NxN: ");
        scanf("%d", &N);
        printf("Введите количество матриц M: ");
        scanf("%d", &M);

        if (N <= 0 || M <= 0) {
            printf("Некорректные размерности матрицы или количество матриц.\n");
            return 1;
        }

        // Создаем массив для M матриц
        int*** matrices = (int***)malloc(M * sizeof(int**));

        // Инициализируем и выделяем память для каждой матрицы
        for (int m = 0; m < M; m++) {
            matrices[m] = (int**)malloc(N * sizeof(int*));
            for (int i = 0; i < N; i++) {
                matrices[m][i] = (int*)malloc(N * sizeof(int));
            }
        }

        // Заполняем матрицы случайными значениями (для примера)
        for (int m = 0; m < M; m++) {
            for (int i = 0; i < N; i++) {
                for (int j = 0; j < N; j++) {
                    matrices[m][i][j] = rand() % 100; // Заполняем случайными числами от 0 до 99
                }
            }
        }
    writeMatricesToFile(matrices,M,N);
    

        // Создаем векторы для хранения сумм
        int** vectors = (int**)malloc(M * sizeof(int*));

        // Находим суммы элементов строк выше главной диагонали для каждой матрицы
        for (int m = 0; m < M; m++) {
            vectors[m] = (int*)malloc(N * sizeof(int));
            for (int i = 0; i < N; i++) {
                vectors[m][i] = 0;
            }

            for (int i = 0; i < N; i++) {
                for (int j = i + 1; j < N; j++) {
                    vectors[m][i] += matrices[m][i][j];
                }
            }
        }
    

        // Выводим результат для каждой матрицы
    writeAnswerToFile(vectors,M, N);
        for (int m = 0; m < M; m++) {
            printf("Суммы элементов строк выше главной диагонали для матрицы %d:\n", m + 1);
            for (int i = 0; i < N; i++) {
                printf("%d ", vectors[m][i]);
            }
            printf("\n");
        }

        // Освобождаем выделенную память
        for (int m = 0; m < M; m++) {
            for (int i = 0; i < N; i++) {
                free(matrices[m][i]);
            }
            free(matrices[m]);
            free(vectors[m]);
        }
        free(matrices);
        free(vectors);

        return 0;
    
  
}
